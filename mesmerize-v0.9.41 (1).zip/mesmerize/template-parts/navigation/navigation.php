<div class="navigation-bar  <?php mesmerize_header_main_class() ?>" <?php mesmerize_navigation_sticky_attrs() ?>>
    <div class="navigation-wrapper <?php mesmerize_navigation_wrapper_class() ?>">
        <div class="logo_col">
            <?php mesmerize_print_logo(); ?>
        </div>
        <div class="main_menu_col">
            <?php mesmerize_print_primary_menu(); ?>
        </div>
    </div>
</div>