<div class="row header-description-row">

    <div class="header-description-top col-xs-12">
        <div class="header-content">
            <div class="<?php print_header_content_holder_class(); ?>">
                <?php mesmerize_print_header_content(); ?>
            </div>
        </div>
    </div>

    <div class="header-description-bottom media col-xs-12 text-center">
        <div class="header-media-container">
            <?php mesmerize_print_header_media(); ?>
        </div>
    </div>
</div>
